# Locate Objects - Locate Solar Panels Freetown - Sierra Leone (3) HOT

YOLO oriented bounding box (OBB) dataset of "solar panel", marked with the Locate auto labeller.

- Project: https://mapswipe.org/en/projects/01M4XM3A1B2WV1T04A8SHV2DBK/
- Volunteer share: 50%
- Model: EdgeTAM
- Images: 20, objects: 36

## Files

- `images/`: one 1024 x 1024 JPEG per tile, named by tile ID (zoom-x-y).
- `labels/`: one YOLO label file per image.
- `data.yaml`: the dataset file for Ultralytics.
- `labels.geojson`: every object as a polygon in longitude and latitude (EPSG:4326), with its tile, source and imagery.

## Open in QGIS

1. In the **Browser** panel, right-click **XYZ Tiles** and choose **New Connection**. Enter a **Name**, paste this URL into **URL**, tick **Max. Zoom Level** and set it to 22, and click **OK**.

   ```text
   https://2glp8ghj65.execute-api.us-east-1.amazonaws.com/cog/tiles/WebMercatorQuad/{z}/{x}/{y}@1x?url=https://oin-hotosm-temp.s3.us-east-1.amazonaws.com/690585b76415e43597ffd7ea/0/690585b76415e43597ffd7eb.tif
   ```

2. Expand **XYZ Tiles** and double-click the new connection to add the imagery to the map.
3. Drag `labels.geojson` into QGIS. It draws above the imagery.
